# weather app

A new Flutter project which fetches and displays data from any city in the World using a free weather API with no key required.

View on YouTube
https://youtu.be/DWZPu0kW2Nk
